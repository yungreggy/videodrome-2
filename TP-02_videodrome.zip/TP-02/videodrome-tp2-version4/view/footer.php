<footer>
    <p>© 2023 Vidéodrôme</p>
</footer>

</body>
</html>