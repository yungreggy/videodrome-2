{{ include('header.php', {title: 'Home'}) }}
    <body>
            <h1 class="videodrome">Videodrôme !</h1>
            <img class="tv-bars" src="{{ path }}/assets/img/tv-bars.jpeg" alt="Description de l'image">
    </body>
</html>